<script src="//cdn.jsdelivr.net/npm/sweetalert2@10"></script>
<link rel="stylesheet" href="../css/main.css">
<?php

/* https://api.telegram.org/bot1802023109:AAETrFhP457Uk5K_rpwL8eXCZPSB1e-XHpQ/getUpdates,
где, XXXXXXXXXXXXXXXXXXXXXXX - токен вашего бота, полученный ранее */

$name = $_POST['ask_username'];
$phone = $_POST['ask_userphone'];
$mail = $_POST['ask_usermail'];
$token = "1802023109:AAETrFhP457Uk5K_rpwL8eXCZPSB1e-XHpQ";
$chat_id = "-550735084";
$arr = array(
  'Имя пользователя: ' => $name,
  'Телефон: ' => $phone,
  'Почта' => $mail,
);

foreach($arr as $key => $value) {
  $txt .= "<b>".$key."</b> ".$value."%0A";
};

$sendToTelegram = fopen("https://api.telegram.org/bot{$token}/sendMessage?chat_id={$chat_id}&parse_mode=html&text={$txt}","r");

if ($sendToTelegram) {

} else {
  echo "Error";
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="apple-touch-icon" sizes="57x57" href="assets/img/apple-icon-57x57.png">
	<link rel="apple-touch-icon" sizes="60x60" href="assets/img/apple-icon-60x60.png">
	<link rel="apple-touch-icon" sizes="72x72" href="assets/img/apple-icon-72x72.png">
	<link rel="apple-touch-icon" sizes="76x76" href="assets/img/apple-icon-76x76.png">
	<link rel="apple-touch-icon" sizes="114x114" href="assets/img/apple-icon-114x114.png">
	<link rel="apple-touch-icon" sizes="120x120" href="assets/img/apple-icon-120x120.png">
	<link rel="apple-touch-icon" sizes="144x144" href="assets/img/apple-icon-144x144.png">
	<link rel="apple-touch-icon" sizes="152x152" href="assets/img/apple-icon-152x152.png">
	<link rel="apple-touch-icon" sizes="180x180" href="assets/img/apple-icon-180x180.png">
	<link rel="icon" type="image/png" sizes="192x192"  href="assets/img/android-icon-192x192.png">
	<link rel="icon" type="image/png" sizes="32x32" href="assets/img/favicon-32x32.png">
	<link rel="icon" type="image/png" sizes="96x96" href="assets/img/favicon-96x96.png">
	<link rel="icon" type="image/png" sizes="16x16" href="assets/img/favicon-16x16.png">
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-eOJMYsd53ii+scO/bJGFsiCZc+5NDVN2yr8+0RDqr0Ql0h+rP48ckxlpbzKgwra6" crossorigin="anonymous">
	<script src="https://kit.fontawesome.com/b8991598b2.js" ></script>
	<meta name="msapplication-TileColor" content="#ffffff">
	<meta name="msapplication-TileImage" content="/ms-icon-144x144.png">
	<meta name="theme-color" content="#ffffff">
	<title>Дякуємо за звернення!</title>
</head>
<body>
	<div class="container">
		<div class="telegram-message">
			<h1><i class="far fa-check-circle"></i> Дякуємо за звернення, у найближчий час наш адміністратор зв'яжеться із вами!</h1>
			<button onclick="document.location='../../katalog.php'" type="button" class="btn btn-outline-danger"><i class="fas fa-shopping-cart"></i> Продовжити покупки</button>
			<button onclick="document.location='../../index.php'" type="button" class="btn btn-outline-danger"><i class="fas fa-sign-in-alt"></i> На головну</button>	
		</div>
		
	</div>
</body>
</html>