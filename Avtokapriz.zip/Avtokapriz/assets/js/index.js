var cart = {};

$('document').ready(function(){
	loadGoods(717);
});

function loadGoods(ord) {
	$.getJSON('goods.json', function(data){
		console.log(data);
		var out = '';
		for (var key in data) {
			if (data[key].ord == ord) {
				out +='<div class="single-goods">';
				out +='<div class="cart">';
				out +=`<div class="cart-img-box"><img src="images/${data[key].img}" alt=""></div>`;
		        out +=`<div class="name">${data[key].name}</div>`;
		        out +=`<div class="description">Опис товару:<br> ${data[key].description}</div>`;
		        out +=`<div class="cost">Ціна: ${data[key].cost} грн</div>`;
		        out +=`<button class="add-to-cart" data-id="${key}">Купити</button>`;
		        out +='</div>';
		        out +='</div>';
	        }else if (ord == 758631){
	        	out +='<div class="single-goods">';
				out +='<div class="cart">';
				out +=`<div class="cart-img-box"><img src="images/${data[key].img}" alt=""></div>`;
		        out +=`<div class="name">${data[key].name}</div>`;
		        out +=`<div class="description">Опис товару:<br> ${data[key].description}</div>`;
		        out +=`<div class="cost">Ціна: ${data[key].cost} грн</div>`;
		        out +=`<button class="add-to-cart" data-id="${key}">Купити</button>`;
		        out +='</div>';
		        out +='</div>';
	        }
	        
		}
		$('#goods').html(out);
		$('.add-to-cart').on('click', addToCart);
	});
};

function addToCart () {
	var id = $(this).attr('data-id');
	//console.log(id);
	if (cart[id]==undefined) {
		cart [id] = 1;
		alert ("Товар додано у кошик");
	}else {
		cart [id]++;
		alert ("Товар додано у кошик");
	}
	showMiniCart();
	saveCart();

}

function saveCart() {
	localStorage.setItem('cart',JSON.stringify(cart));
}

function showMiniCart() {
	var out = "";
	for (var key in cart) {
		out += key +' --- '+ cart[key]+'<br>';
	}
	$('.mini-cart').html(out);
}

function loadCart () {
	if (localStorage.getItem('cart')) {
		cart = JSON.parse(localStorage.getItem('cart'));
		showMiniCart();
	}
}
$(document).ready(function() {
	loadCart();
});