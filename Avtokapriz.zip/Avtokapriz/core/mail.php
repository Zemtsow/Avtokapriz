<?php
// читать json файл
$json = file_get_contents('../goods.json');
$json = json_decode($json, true);

$token = "1802023109:AAETrFhP457Uk5K_rpwL8eXCZPSB1e-XHpQ";
$chat_id = "-550735084";
$zakaz = "Замовлення з сайту:";
$list = "___________________________________";
//письмо
$ephone =$_POST['ephone'];
$email = $_POST['email'];
$ename = $_POST['ename'];
$cart = $_POST['cart'];
$sum = 0;
foreach ($cart as $id=>$count) {
    $gname .="%0A".$json[$id]['name'].'---'.$count.'шт'.'---'.$count*$json[$id]['cost'].' грн; '."%0A";
    $sum = $sum +$count*$json[$id]['cost'].' грн;';
}
$message .='Всего: '.$sum;
print_r($message);


$arr = array(
  ' ' => $zakaz,
  'Имя користувача: ' => $ename,
  'Телефон: ' => $ephone,
  'Пошта: ' => $email,
  'Назва товару: ' => $gname,
  '' => $list,
  'Усього: ' => $sum,
);

foreach($arr as $key => $value) {
  $txt .= "<b>"."%0A".$key."%0A"."</b> ".$value."%0A";
};

$sendToTelegram = fopen("https://api.telegram.org/bot{$token}/sendMessage?chat_id={$chat_id}&parse_mode=html&text={$txt}","r");

if ($sendToTelegram) {echo 1;} else {echo 0;}